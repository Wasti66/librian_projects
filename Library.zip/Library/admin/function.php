
<?php

	class lMs{
		
		public $conn;
		
		public function __construct(){
			$host_name = "localhost";
			$host_user = "root";
			$db_pass = "";
			$db_name = "lms";
			
			$this->conn = mysqli_connect($host_name,$host_user,$db_pass,$db_name);
			if(!$this->conn){
				echo "Data base connection error";
			}
		}
		
		/* -- === student panal === -- */
		
		/* -- === student registration form === -- */
		public function student_reg($student_data){
			
			$name = ucfirst($student_data['name']);
			$email = $student_data['email'];
			$roll = $student_data['roll'];
			$reg = $student_data['reg'];
			$phone = $student_data['phone'];
			$password = md5($student_data['password']);
			//$lowercase = preg_match('@[a-z]@',$password);
			
			$error = [];
			
			/* --- === name checking === -- */
			$name_check = "SELECT * FROM students WHERE name='$name'";
			$checking_mysqli_query_name = mysqli_query($this->conn,$name_check);
			$checking_row_name = mysqli_num_rows($checking_mysqli_query_name);
			
			/* --- === email checking === -- */
			$email_check = "SELECT * FROM students WHERE email='$email'";
			$checking_mysqli_query_email = mysqli_query($this->conn,$email_check);
			$checking_row_email = mysqli_num_rows($checking_mysqli_query_email);
			
			/* --- === phone checking === -- */
			$phone_check = "SELECT * FROM students WHERE phone='$phone'";
			$checking_mysqli_query_phone = mysqli_query($this->conn,$phone_check);
			$checking_row_phone = mysqli_num_rows($checking_mysqli_query_phone);
			
			if($checking_row_name == 1){
				$error['check_name'] = "This name allready registerd";
			}
			if($checking_row_email == 1){
				$error['check_email'] = "This email allready registerd";
			}
			if($checking_row_phone == 1){
				$error['check_phone'] = "This Phone number allready registerd";
			}
			if(strlen($name) < 3 || strlen($name) > 32){
				$error['name'] = "Name must be 3-32 character";
			}
			if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
				$error['email'] = "Invalid email formet";
			}
			if(strlen($roll) > 6 || !is_numeric($roll)){
				$error['roll'] = "6 character maximum and integer number";
			}
			if(strlen($reg) > 6 || !is_numeric($reg)){
				$error['reg'] = "6 character maximum and integer number";
			}
			if(strlen($phone) < 11 || !is_numeric($phone)){
				$error['phone'] = "phone number must be at 11 character & integer number";
			}
			if(strlen($password) < 6){
				$error['password'] = "Password must be 6 Character";
			}
			
			if(count($error) > 0){
				
				$action = [
					'status' => 'error',
					'message' => $error,
				];
				return $action;
				
			}else{
				
				//$password_hash = password_hash($password,PASSWORD_DEFAULT);

				$student_info_insert = "INSERT INTO students(name,email,roll,reg,phone,password,status) VALUES('$name','$email',$roll,$reg,$phone,'$password',0)";
				if(mysqli_query($this->conn,$student_info_insert)){
					
					$subject_r = "Library management system";
					$body_r = "Registration Successfully";
					$from_r = "From: purnota54321@gmail";
					mail($email,$subject_r,$body_r,$from_r);
					
					$action = [
						'status' => 'success',
						'message' => 'Registration Successfully',
					];
					return $action;
				}
			}
			
		}
		
		/* -- === student login form === -- */
		public function student_login($student_log_data){
			
			$login_email = $student_log_data['login_email'];
			$login_pass = md5($student_log_data['login_pass']);

			$student_login_sql = "SELECT * FROM students WHERE email='$login_email' OR name='$login_email'";
			$query = mysqli_query($this->conn,$student_login_sql);
			
			if(mysqli_num_rows($query) == 1){
				$student_assoc = mysqli_fetch_assoc($query);
				if($login_pass == $student_assoc['password']){
					
					if($student_assoc['status'] == 1){
						session_start();
						$_SESSION['id'] = $student_assoc['id'];
						$_SESSION['email'] = $student_assoc['email'];
						$_SESSION['name'] = $student_assoc['name'];
						//$_SESSION['img'] = $student_assoc['img'];
						header('location:index.php');
					}else{
						$return_msg = "Your Status is inactive. Please Contact Libraiyan";
						return $return_msg;
					}
					
				}else{
					$return_msg = "Your Password is Invalid";
					return $return_msg;
				}
				
			}else{
				$return_msg = "Your Email or Name is Invalid";
				return $return_msg;
			}
			
		}
		
		/* -- === student forget password === -- */
		public function forget_password($forget_pass){
			$to_email = $forget_pass['to_email'];
			$recovery_query = "SELECT * FROM students WHERE email='$to_email'";
			$mysqli_query = mysqli_query($this->conn,$recovery_query);
			$count_email = mysqli_num_rows($mysqli_query);
			
			if($count_email > 0){
				while($assoc = mysqli_fetch_assoc($mysqli_query)){
					$passowrd = $assoc['password'];
					
					$subject = "Password recovery";
					$body = "Your password is: $passowrd";
					$headers = "From: purnota54321@gmail.com";
					
					if(mail($to_email,$subject,$body,$headers)){
						$veryfy = "Your passrowd send to ".$to_email;
						return $veryfy;
					}else{
						$veryfy = "Password recover failed";
						return $veryfy;
					}
				}
			}else{
				$veryfy = "This email are not found";
				return $veryfy;
			}
		}
		
		
	}

	

?>
