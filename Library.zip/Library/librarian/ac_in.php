<?php 
	
	require_once('librian_fn.php');
	$obj = new lMstu();
	
	// student active and inactive
	if(isset($_GET['id'])){
		$id = base64_decode($_GET['id']);
		$obj->student_inactive($id);
		header('location:students.php');
	}
	if(isset($_GET['id_ac'])){
		$id_ac = base64_decode($_GET['id_ac']);
		$obj->student_active($id_ac);
		header('location:students.php');
	}
	// librian active and inactive
	if(isset($_GET['inactivelib'])){
		$inactivelib = base64_decode($_GET['inactivelib']);
		$obj->librian_inactive($inactivelib);
		header('location:librian_profail.php');
	}
	if(isset($_GET['activelib'])){
		$activelib = base64_decode($_GET['activelib']);
		$obj->librian_active($activelib);
		header('location:librian_profail.php');
	}
	
?>