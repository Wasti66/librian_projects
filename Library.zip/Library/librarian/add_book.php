<?php 
	
	require_once('librian_fn.php');
	$obj = new lMstu();
	
	if(isset($_POST['add_book_btn'])){
		$old_value = $_POST;
		$check = $obj->add_book($_POST);
		if($check['status'] == 'error'){
			$error = $check['message'];
		}else{
			$success = $check['message'];
		}
	}
	
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <section class="bg-light shadow-sm pb-3">
			<div class="container">
			  <div class="row">
			    <div class="col">
				  <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
					  <ol class="breadcrumb mb-0">
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="index.php" class="text-decoration-none">Dashboard</a></li>
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="" class="text-decoration-none"></a>Add book</li>
					  </ol>
				  </nav>
				</div>
			  </div> 
			</div>
		</section>
	    <!-- ===== add books ====== -->
	    <section>
			<div class="container">
			  <div class="row justify-content-center">
			    <div class="col-md-10">
				  <?php
					if(isset($success)){
						echo '<div class="alert alert-info">'.$success.'</div>';
					}
				  ?>
				  <h3 class="text-capitalize fw-bold mb-3">add books</h3>
				  <div class="card card-body shadow-sm bg-light border-0">
				  
				    <form action="" method="post" enctype="multipart/form-data">
					  <!-- === book name ==== -->
					  <div class="mb-3">
						 <label class="form-label">Book Name<span class="text-danger">*</span></label>
						 <input type="text" name="book_name" class="form-control box-shadow-none text-capitalize" value="<?= isset($error) && count($error) > 0 ? $old_value['book_name'] : '' ?>">
						 <?php
							if(isset($error) && isset($error['book_name'])){
								echo '<span class="text-danger">'.$error['book_name'].'</span>';
							}
						 ?>
					  </div>
					  <!-- === book images ==== -->
					  <div class="mb-3">
						 <label class="form-label">Book Image<span class="text-danger">*</span></label>
						 <input type="file" name="img_name" class="form-control box-shadow-none">
						 <?php
							if(isset($error) && isset($error['img_ext'])){
								echo '<span class="text-danger">'.$error['img_ext'].'</span>';
							}
						 ?>
						 <?php
							if(isset($error) && isset($error['img_size'])){
								echo '<span class="text-danger">'.$error['img_size'].'</span>';
							}
						 ?>
					  </div>
					  <!-- === author name ==== -->
					  <div class="mb-3">
						 <label class="form-label">Book Author Name<span class="text-danger">*</span></label>
						 <input type="text" name="book_autor_name" class="form-control box-shadow-none text-capitalize" value="<?= isset($error) && count($error) > 0 ? $old_value['book_autor_name'] : '' ?>">
						 <?php
							if(isset($error) && isset($error['author_name'])){
								echo '<span class="text-danger">'.$error['author_name'].'</span>';
							}
						 ?>
					  </div>
					  <!-- === book publication name ==== -->
					  <div class="mb-3">
						 <label class="form-label">Book Publication Name<span class="text-danger">*</span></label>
						 <input type="text" name="book_publication_name" class="form-control box-shadow-none text-capitalize" value="<?= isset($error) && count($error) > 0 ? $old_value['book_publication_name'] : '' ?>">
						 <?php
							if(isset($error) && isset($error['book_publication_name'])){
								echo '<span class="text-danger">'.$error['book_publication_name'].'</span>';
							}
						 ?>
					  </div>
					  <!-- === book Purchase Date ==== -->
					  <div class="mb-3">
						 <label class="form-label">Purchase Date<span class="text-danger">*</span></label>
						 <input type="date" name="purchase_date" class="form-control box-shadow-none">
						 <?php
							if(isset($error) && isset($error['date'])){
								echo '<span class="text-danger">'.$error['date'].'</span>';
							}
						 ?>
					  </div>
					  <!-- === book Price ==== -->
					  <div class="mb-3">
						 <label class="form-label">Book Price<span class="text-danger">*</span></label>
						 <input type="number" name="book_price" class="form-control box-shadow-none" value="<?= isset($error) && count($error) > 0 ? $old_value['book_price'] : '' ?>">
						 <?php
							if(isset($error) && isset($error['book_int'])){
								echo '<span class="text-danger">'.$error['book_int'].'</span>';
							}
						 ?>
					  </div>
					  <!-- === book Quantity ==== -->
					  <div class="mb-3">
						 <label class="form-label">Book Quantity<span class="text-danger">*</span></label>
						 <input type="number" name="book_qty" class="form-control box-shadow-none" value="<?= isset($error) && count($error) > 0 ? $old_value['book_qty'] : '' ?>">
						 <?php
							if(isset($error) && isset($error['book_qty'])){
								echo '<span class="text-danger">'.$error['book_qty'].'</span>';
							}
						 ?>
						 <?php
							if(isset($error) && isset($error['book_qty_digit'])){
								echo '<span class="text-danger">'.$error['book_qty_digit'].'</span>';
							}
						 ?>
					  </div>
					  <!-- === available quentity ==== -->
					  <div class="mb-3">
						 <label class="form-label">Available Quantity<span class="text-danger">*</span></label>
						 <input type="number" name="available_qty" class="form-control box-shadow-none" value="<?= isset($error) && count($error) > 0 ? $old_value['available_qty'] : '' ?>">
						 <?php
							if(isset($error) && isset($error['available_qty'])){
								echo '<span class="text-danger">'.$error['available_qty'].'</span>';
							}
						 ?>
					  </div>
					  <button type="submit" name="add_book_btn" class="btn btn-primary box-shadow-none text-capitalize"><i class="fa-regular fa-floppy-disk me-2"></i>add book</button>
					</form>
					
				  </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>