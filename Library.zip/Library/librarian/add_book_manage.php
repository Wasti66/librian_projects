<?php 
	
	require_once('librian_fn.php');
	$obj = new lMstu();
	$data = $obj->display_books();
	
	if(isset($_POST['img_update'])){
		$msg = $obj->books_img_update($_POST);
		
	}
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <section class="bg-light shadow-sm pb-3">
			<div class="container">
			 <?php
				if(isset($msg)){
					echo $msg;
				}
			  ?>
			  <div class="row">
			    <div class="col">
				  <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
					  <ol class="breadcrumb mb-0">
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="index.php" class="text-decoration-none">Dashboard</a></li>
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="javascript:avoid(0)" class="text-decoration-none">Manage book</a></li>
					  </ol>
				  </nav>
				</div>
			  </div> 
			</div>
		</section>
	    <!-- ===== home part ====== -->
	    <section>
			<div class="container">
			  <div class="row">
			    <div class="col-12">
				  <h3 class="text-capitalize">manage book</h3>
				  <div class="card card-body shadow-sm border-0 bg-light">
				    <div class="table-responsive">
					  <table class="table table-hover table-bordered border-primary">
					    <thead>
						  <tr>
							<th class="small">SL.NO</th>
							<th class="small">Book Name</th>
							<th class="small">Image</th>
							<th class="small">Publication</th>
							<th class="small">Author Name</th>
							<th class="small">Purchase Date</th>
							<th class="small">Price</th>
							<th class="small">Quentity</th>
							<th class="small">Avable Quentity</th>
							<th class="small">View</th>
							<th class="small">Updare</th>
							<th class="small">Delete</th>
						  </tr>
						</thead>
						<tbody>
						<?php while($row = mysqli_fetch_assoc($data)){ ?>
						  <tr>
							<td class="small"><?php echo $row['id']; ?></td>
							<td class="small"><?php echo $row['book_name']; ?></td>
							<td class="small">
							
							    <img src="upload/<?php echo $row['book_images']; ?>" class="w-4">
							    <br>
							    <!-- update images molal -->
								<a class="text-dark font-weight-600" data-bs-toggle="modal" data-bs-target="#img_change-<?php echo $row['id']; ?>" href="?imgid=<?php echo $row['id']; ?>">change image</a>
								
								<!-- Modal -->
								<div class="modal fade" id="img_change-<?php echo $row['id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
									<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
									  <div class="modal-content">
										  <div class="modal-header bg-primary">
											<h5 class="modal-title text-white" id="exampleModalLabel">Update images</h5>
											<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
										  </div>
										  <div class="modal-body bg-light">
											  <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" enctype="multipart/form-data">
												<input type="hidden" name="img_id" value="<?php echo $row['id']; ?>">
												<input type="file" name="up_img" class="form-control box-shadow-none mb-3">
												<img src="upload/<?php echo $row['book_images']; ?>" class="w-6">
												<br>
												<input type="submit" name="img_update" class="btn btn-primary box-shadow-none mt-3" value="Update Image">
											  </form>
										  </div>
										  <div class="modal-footer bg-light">
											<button type="button" class="btn btn-dark" data-bs-dismiss="modal">Close</button>
										  </div>
									  </div>
									</div>
								</div>
							  
							</td>
							<td class="small"><?php echo $row['book_publicaton_name']; ?></td>
							<td class="small"><?php echo $row['book_autor_name']; ?></td>
							<td class="small"><?php echo $row['book_purchase_date']; ?></td>
							<td class="small"><?php echo $row['book_price']; ?> BDT/-</td>
							<td class="small"><?php echo $row['book_qty']; ?></td>
							<td class="small"><?php echo $row['avable_qty']; ?></td>
							
							<td>
							   <!-- book detals view -->
							   <a href="javascript:avoid(0)" class="btn btn-primary box-shadow-none btn-sm" data-bs-toggle="modal" data-bs-target="#book-<?php echo $row['id']; ?>"><i class="fa-regular fa-eye"></i></a>
								  
							  <div class="modal fade" id="book-<?php echo $row['id']; ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
							  <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-md-lg">
								
								<div class="modal-content bg-light">
								  <div class="modal-header bg-primary">
									<h5 class="modal-title text-capitalize text-white" id="staticBackdropLabel"><i class="fa-solid fa-book-open-reader me-2"></i>books information</h5>
									<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
								  </div>
								  <div class="modal-body">
									<div class="table-responsive">
									  <table class="table table-hover table-bordered border-primary">
										<tbody>
										  <tr>
											<th class="">Book Name</th>
											<th class=""><?php echo $row['book_name']; ?></th>
										  </tr>
										  <tr>
											<th class="">Book Images</th>
											<th class=""><img src="upload/<?php echo $row['book_images']; ?>" class="w-6"></th>
										  </tr>
										  <tr>
											<th class="">Book Publication</th>
											<th class=""><?php echo $row['book_publicaton_name']; ?></th>
										  </tr>
										  <tr>
											<th class="">Author Name</th>
											<th class=""><?php echo $row['book_autor_name']; ?></th>
										  </tr>
										  <tr>
											<th class="">Purchase Date</th>
											<th class=""><?php echo $row['book_purchase_date']; ?></th>
										  </tr>
										  <tr>
											<th class="">Book Price</th>
											<th class=""><?php echo $row['book_price']; ?> BDT/-</th>
										  </tr>
										  <tr>
											<th class="">Book Quentity</th>
											<th class=""><?php echo $row['book_qty']; ?></th>
										  </tr>
										  <tr>
											<th class="">Avable Quentity</th>
											<th class=""><?php echo $row['avable_qty']; ?></th>
										  </tr>
										</tbody>
									  </table>
									</div>
								  </div>
								  <div class="modal-footer">
									<button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
								  </div>
								</div>
							  </div>
							 </div>
							</td>
							<td class="small">
							  <!-- === add books edit link === -->
							  <a class="btn btn-success box-shadow-none btn-sm me-md-1" href="addbooks_update.php?status&&editid=<?php echo base64_encode($row['id']); ?>">
							    <i class="fa-regular fa-pen-to-square"></i>
							  </a>
							</td>
							<td class="small">
							  <!-- === add books delete link === -->
							  <a class="btn btn-danger box-shadow-none btn-sm" href="delete.php?deleteid=<?php echo base64_encode($row['id']); ?>" onclick="return confirm('Are you confirm to delete?')">
							    <i class="fa-regular fa-trash-can"></i>
							  </a>
							</td>
						  </tr>
						<?php } ?>	
						</tbody>
					  </table>
					</div>
				  </div>
				</div>
			  </div> 
			</div>
		</section>
		  
		  
		
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>