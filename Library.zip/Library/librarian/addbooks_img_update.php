<?php 
	<a class="text-dark font-weight-600" href="addbooks_img_update.php?imgid=<?php echo base64_encode($row['id']); ?>">change image</a>
	require_once('librian_fn.php');
	$obj = new lMstu();
	if(isset($_GET['imgid'])){
		$id = base64_decode($_GET['imgid']);
		$data = $obj->display_books_id($id);
		$value = mysqli_fetch_assoc($data);
	}
	if(isset($_POST['img_update'])){
		$msg = $obj->books_img_update($_POST);
	}
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <section class="bg-light shadow-sm pb-3">
			<div class="container">
			  <div class="row">
			    <div class="col">
				  <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
					  <ol class="breadcrumb mb-0">
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="index.php" class="text-decoration-none">Dashboard</a></li>
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="" class="text-decoration-none"></a>Add Books Image Update</li>
					  </ol>
				  </nav>
				</div>
			  </div> 
			</div>
		</section>
	    <!-- ===== home part ====== -->
	    <section>
			<div class="container">
			  <div class="row">
			    <div class="col-md-6">
				  <h3 class="text-capitalize fw-bold mb-3">books image update</h3>
				  <?php
					if(isset($msg)){
						echo $msg;
					}
				  ?>
				  <form action="" method="post" enctype="multipart/form-data">
				    <input type="hidden" name="img_id" value="<?php echo $value['id'];?>">
				    <input type="file" name="up_img" class="form-control box-shadow-none mb-3">
					<img src="upload/<?php echo $value['book_images']; ?>" class="w-6">
					<br>
					<input type="submit" name="img_update" class="btn btn-primary box-shadow-none mt-3" value="Update Image">
				  </form>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>