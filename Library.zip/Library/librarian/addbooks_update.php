<?php 
	
	require_once('librian_fn.php');
	$obj = new lMstu();
	if(isset($_GET['status'])){
		$id = base64_decode($_GET['editid']);
		$value = $obj->display_books_id($id);
		$row = mysqli_fetch_assoc($value);
	}
	
	if(isset($_POST['up_add_book_btn'])){
		$seccess = $obj->update_books($_POST);
	}
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <section class="bg-light shadow-sm pb-3">
			<div class="container">
			  <div class="row">
			    <div class="col">
				  <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
					  <ol class="breadcrumb mb-0">
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="index.php" class="text-decoration-none">Dashboard</a></li>
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="" class="text-decoration-none"></a>Add Books Update</li>
					  </ol>
				  </nav>
				</div>
			  </div> 
			</div>
		</section>
	    <!-- ===== home part ====== -->
	    <section>
			<div class="container">
			  <div class="row">
			    <div class="col-md-10">
				  <h3 class="text-capitalize fw-bold mb-3">updates books</h3>
				  <?php
					if(isset($seccess)){
						echo '<div class="alert alert-primary">'.$seccess.'</div>';
					}
				  ?>
				  <div class="card card-body bg-light border-0 shadow-sm">
				  
				    <form action="" method="post">
					  <!-- === id ==== -->
					  <input type="hidden" name="up_id" value="<?php echo $row['id']; ?>">
					  <!-- === update book name ==== -->
					  <div class="mb-3">
						 <label class="form-label">Update Book Name<span class="text-danger">*</span></label>
						 <input type="text" name="up_book_name" class="form-control box-shadow-none text-capitalize" value="<?php echo $row['book_name']; ?>" Required>
						 
					  </div>
					  <!-- === update author name ==== -->
					  <div class="mb-3">
						 <label class="form-label">Update Author Name<span class="text-danger">*</span></label>
						 <input type="text" name="up_book_autor" class="form-control box-shadow-none text-capitalize" value="<?php echo $row['book_autor_name']; ?>" Required>
						 
					  </div>
					  <!-- === update book publication name ==== -->
					  <div class="mb-3">
						 <label class="form-label">Update Publication Name<span class="text-danger">*</span></label>
						 <input type="text" name="up_publication_name" class="form-control box-shadow-none text-capitalize" value="<?php echo $row['book_publicaton_name']; ?>" Required>
						 
					  </div>
					  <!-- === update book Purchase Date ==== -->
					  <div class="mb-3">
						 <label class="form-label">Update Purchase Date<span class="text-danger">*</span></label>
						 <input type="date" name="up_purchase_date" class="form-control box-shadow-none" value="<?php echo $row['book_purchase_date']; ?>" Required>
					  </div>
					  <!-- === update book Price ==== -->
					  <div class="mb-3">
						 <label class="form-label">Update Book Price<span class="text-danger">*</span></label>
						 <input type="number" name="up_book_price" class="form-control box-shadow-none" value="<?php echo $row['book_price']; ?>" Required>

					  </div>
					  <!-- === update book Quantity ==== -->
					  <div class="mb-3">
						 <label class="form-label">Update Book Quantity<span class="text-danger">*</span></label>
						 <input type="number" name="up_book_qty" class="form-control box-shadow-none" value="<?php echo $row['book_qty']; ?>" Required>
						 
					  </div>
					  <!-- === update available quentity ==== -->
					  <div class="mb-3">
						 <label class="form-label">Update Available Quantity<span class="text-danger">*</span></label>
						 <input type="number" name="up_available_qty" class="form-control box-shadow-none" value="<?php echo $row['avable_qty']; ?>" Required>

					  </div>
					  <button type="submit" name="up_add_book_btn" class="btn btn-primary box-shadow-none text-capitalize"><i class="fa-regular fa-pen-to-square me-2"></i>Update book</button>
					</form>
					
				  </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>