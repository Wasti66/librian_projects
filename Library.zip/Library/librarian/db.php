<?php

	$host_name = "localhost";
	$host_user = "root";
	$db_pass = "";
	$db_name = "lms";
	
	$conn = mysqli_connect($host_name,$host_user,$db_pass,$db_name);
	
?>