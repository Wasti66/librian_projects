<?php

	require_once('librian_fn.php');
	$obj = new lMstu();
	
	// add books info delete
	if(isset($_GET['deleteid'])){
		$id = base64_decode($_GET['deleteid']);
		$obj->books_delete($id);
		header('location:add_book_manage.php');
	}
	// librian info delete
	if(isset($_GET['libprofiledelete'])){
		$libprofiledelete = base64_decode($_GET['libprofiledelete']);
		$obj->profile_delete($libprofiledelete);
		header('location:librian_profail.php');
	}

?>