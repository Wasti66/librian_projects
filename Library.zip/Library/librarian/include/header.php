
<?php
	session_start();
	if(!isset($_SESSION['username'])){
		header('location:login.php');
	}
?>

<header>
	    <!-- ==== nav bar === -->
	    <nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="#">Navbar</a>
			
			<button class="navbar-toggler me-auto box-shadow-none d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
			  <span class="navbar-toggler-icon" data-bs-target="#offcanvasExample"></span>
		    </button>
			
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			   <span class="navbar-toggler-icon"></span>
			</button>
			
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
			  <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
			    <li class="nav-item">
				  <a class="nav-link btn btn-dark box-shadow-none text-white" aria-current="page" href="librianlogout.php">Logout</a>
				</li>
			   </ul>	
			</div>
		  </div>
		</nav>
		<!-- ==== side nav bar === -->
		<div class="offcanvas offcanvas-start bg-dark shadow-sm border-0" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
		  <div class="offcanvas-header ms-auto p-1">
			<button type="button" class="btn btn-sm box-shadow-none text-reset d-md-none" data-bs-dismiss="offcanvas" aria-label="Close">
			   <i class="fa-solid fa-xmark fa-2x text-info"></i>
			</button>
		  </div>
		  <div class="offcanvas-body p-0">
		    <ul class="nav flex-column">
			  <!-- ==== home ==== -->
			  <li class="<?= $page == 'index.php' ? 'nav-item': '' ?>">
				<a class="nav-link text-white" href="index.php"><i class="fa-solid fa-house"></i> Dashboard</a>
			  </li>
			  <!-- ==== students ==== -->
			  <li class="<?= $page == 'students.php' ? 'nav-item': '' ?>">
				<a class="nav-link text-white" href="students.php"><i class="fa-solid fa-users"></i> Students</a>
			  </li>
			  <!-- ==== books ==== -->
			  <div class="accordion accordion-flush" id="accordionFlushExample">
				  <div class="accordion-item bg-transparent">
					<h2 class="accordion-header" id="flush-headingOne">
					  <button class="accordion-button collapsed bg-dark text-white box-shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
						<i class="fa-solid fa-book-open me-2"></i>Books
					  </button>
					</h2>
					<div id="flush-collapseOne" class="accordion-collapse collapse <?= $page == 'add_book_manage.php' ? 'show': '' ?><?= $page == 'add_book.php' ? 'show': '' ?>" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
					  <!-- ==== add books ==== -->
					  <li class="<?= $page == 'add_book.php' ? 'nav-item': '' ?>">
						<a class="nav-link text-white" href="add_book.php">Add Book</a>
					  </li>
					  <!-- ==== namage books ==== -->
					  <li class="<?= $page == 'add_book_manage.php' ? 'nav-item': '' ?>">
						<a class="nav-link text-white" href="add_book_manage.php">Manage Book</a>
					  </li>
					  
					</div>
				  </div>
			  </div>
			  <!-- ==== issue books ==== -->
			  <li class="<?= $page == 'issue_book.php' ? 'nav-item': '' ?>">
				<a class="nav-link text-white" href="issue_book.php"><i class="fa-solid fa-passport me-2"></i>Issue Books</a>
			  </li>
			  <!-- ==== return books ==== -->
			  <li class="<?= $page == 'return_book.php' ? 'nav-item': '' ?>">
				<a class="nav-link text-white" href="return_book.php"><i class="fa-solid fa-arrow-rotate-left me-2"></i>Retrn Books</a>
			  </li>
			  <!-- ==== librian profile ==== -->
			  <li class="<?= $page == 'librian_profail.php' ? 'nav-item': '' ?>">
				<a class="nav-link text-white" href="librian_profail.php"><i class="fa-solid fa-user me-2"></i></i>Profile</a>
			  </li>
			  <li class="<?= $page == 'librian_changepass.php' ? 'nav-item': '' ?>">
				<a class="nav-link text-white" href="librian_changepass.php"><i class="fa-solid fa-shield me-2"></i></i>Change Password</a>
			  </li>
			</ul>
		  </div>
		</div>
	 </header>