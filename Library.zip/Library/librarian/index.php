<?php 
	
	require_once('librian_fn.php');
	$obj = new lMstu();
	$student_info = $obj->total_student();
	$student_row = mysqli_num_rows($student_info);
	
	$book_info = $obj->total_books();
	$book_row = mysqli_num_rows($book_info);
	
	$librian_info = $obj->total_librian();
	$librian_row = mysqli_num_rows($librian_info);
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <section class="bg-light shadow-sm pb-3">
			<div class="container">
			  <div class="row">
			    <div class="col">
				  <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
					  <ol class="breadcrumb mb-0">
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="index.php" class="text-decoration-none">Dashboard</a></li>
					  </ol>
				  </nav>
				</div>
			  </div> 
			</div>
		</section>
	    <!-- ===== home part ====== -->
	    <section class="">
			<div class="container">
			  <div class="row">
			    <!-- ===== total librian librian ====== -->
			    <div class="col-md-4 col-sm-6 mb-md-0 mb-3">
				  <a href="librian_profail.php" class="text-decoration-none">
				    <div class="card card-body bg-primary text-center border-0 shadow-sm">
					   <i class="fa-solid fa-user-tie fa-2x text-white"></i>
					   <h4 class="text-capitalize font-weight-400 text-white mt-3 mb-3">tolal librian</h4>
					   <h5 class="text-capitalize font-weight-600 text-white"><?php echo $librian_row; ?></h5>
				    </div>
				  </a>
				</div>
			    <!-- ===== total students ====== -->
			    <div class="col-md-4 col-sm-6 mb-md-0 mb-3">
				  <a href="students.php" class="text-decoration-none">
				    <div class="card card-body bg-primary text-center shadow-sm border-0">
					   <i class="fa-solid fa-users fa-2x text-white"></i>
					   <h4 class="text-capitalize font-weight-400 text-white mt-3 mb-3">tolal students</h4>
					   <h5 class="text-capitalize font-weight-600 text-white"><?php echo $student_row; ?></h5>
				    </div>
				  </a>
				</div>
				<!-- ===== total books ====== -->
				<?php
				    require_once('../students/db.php');
					$tolat_books_qty = "SELECT sum(book_qty) as total FROM books";
					$total_books_qty_query = mysqli_query($conn,$tolat_books_qty);
					$tolat_book_qty_accoc = mysqli_fetch_assoc($total_books_qty_query);
				?>
			    <div class="col-md-4 col-sm-6 mb-md-0 mb-3">
				  <a href="add_book_manage.php" class="text-decoration-none">
				    <div class="card card-body bg-primary text-center border-0 shadow-sm">
					   <i class="fa-solid fa-book fa-2x text-light"></i>
					   <h4 class="text-capitalize font-weight-400 text-white mt-3 mb-3">tolal books</h4>
					   <h5 class="text-capitalize font-weight-600 text-white"><?= $book_row . ' ('. $tolat_book_qty_accoc['total'] .')' ?></h5>
				    </div>
				  </a>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>