<?php 
	
	require_once('librian_fn.php');
	$obj = new lMstu();
	$data = $obj->studen_info_active();
	$value = $obj->issue_books();
	
	if(isset($_POST['book_issue_btn'])){
		$success_msg = $obj->issue_books_insert($_POST);
		
		if($success_msg){
			?>
			
			<script type="text/javascript">
			  alert('Book issue Successfully');
			</script>
			
			<?php
		}
	
	}
	
	
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <section class="bg-light shadow-sm pb-3">
			<div class="container">
			  <div class="row">
			    <div class="col">
				  <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
					  <ol class="breadcrumb mb-0">
						<li class="breadcrumb-item font-weight-600 text-dark">
						   <a href="index.php" class="text-decoration-none">Dashboard</a>
						</li>
						<li class="breadcrumb-item font-weight-600 text-dark">
						  <a href="javascript:avoid(0)" class="text-decoration-none">Issue Books</a>
						</li>
					  </ol>
				  </nav>
				</div>
			  </div> 
			</div>
		</section>
	    <!-- ===== home part ====== -->
	    <section>
			<div class="container">
			  <div class="row justify-content-center">
			    <div class="col-lg-6 col-md-8">
				  <div class="card card-body bg-light shadow-sm">
				  
				    <form action="" method="post">
					  <div class="d-flex">
					    <select class="form-select box-shadow-none me-2" name="student_id">
						  <option>Select</option>
						 <?php while($row = mysqli_fetch_assoc($data)){ ?>
						  <option value="<?php echo $row['id']; ?>"><?= $row['name'].' ('.$row['roll'].')' ?></option>
						 <?php } ?>
						</select>
						<input type="submit" name="search" class="btn btn-primary" vlaue="Search">
					  </div>
					</form>
					<?php
					
						if(isset($_POST['search'])){
							$stu_info = $obj->student_info_id($_POST);
							$row = mysqli_fetch_assoc($stu_info);
							//print_r($row);
							?>
							 
							<form action="" method="post">
								<div class="mb-3">
								   <label class="form-label">Student Name</label>
								   <input type="text" class="form-control box-shadow-none" name="" value="<?php echo $row['name']; ?>" readonly>
								</div>
								<input type="hidden" name="student_id" value="<?php echo $row['id']; ?>">
								<label class="form-label">Book Name</label>
								<select class="form-select box-shadow-none mb-3" name="book_id">
									<?php while($book_data = mysqli_fetch_assoc($value)){ ?>
									   <option value="<?php echo $book_data['id'] ?>"><?php echo $book_data['book_name'] ?></option>;
									<?php } ?>
								</select>
								<div class="mb-3">
								   <label class="form-label">Book Issue Date</label>
								   <input type="text" class="form-control box-shadow-none" name="book_issue_date" value="<?php echo date('d-M-y'); ?>" readonly>
								</div>
								<input type="submit" name="book_issue_btn" class="btn btn-primary box-shadow-none" value="Save Issue Book">
							</form>	
							 
							 
							<?php
						}
					
					?>
				  </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>