<?php 
	
	require_once('librian_fn.php');
	require_once('../students/db.php');
	$obj = new lMstu();
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <section class="bg-light shadow-sm pb-3">
			<div class="container">
			  <div class="row">
			    <div class="col">
				  <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
					  <ol class="breadcrumb mb-0">
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="index.php" class="text-decoration-none">Dashboard</a></li>
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="javascript:avoid(0)" class="text-decoration-none">Change Password</a></li>
					  </ol>
				  </nav>
				</div>
			  </div> 
			</div>
		</section>
	    <!-- ===== librian change password ====== -->
	    <section class="">
			<div class="container">
			  <div class="row justify-content-center">
				
				<?php
					
					$currnet_pass=$new_pass_str=$password_success='';
					if(isset($_POST['libchange_btn'])){
						$id = $_SESSION['id'];
						$select = "SELECT * FROM librian WHERE id=$id";
						$query = mysqli_query($conn,$select);
						$fatch = mysqli_fetch_assoc($query);
						$old_pass = $fatch['password'];
						
						$current_pass = md5($_POST['current_pass']);
						$new_pass = md5($_POST['new_pass']);
						$confirm_pass = md5($_POST['confirm_pass']);
						
						if($old_pass !== $current_pass){
							$currnet_pass = "Current Password is worng";
						}elseif($new_pass !== $confirm_pass){
							$new_pass_str = "New Password and Confirm are not match";
						}else{
							$update_pass = "UPDATE librian SET password='$new_pass' WHERE id=$id";
							$update_query = mysqli_query($conn,$update_pass);
							if($update_query){
								$password_success = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
												  <strong>password Change Successfully</strong>
												  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
												</div>';
							}
						}
						
					}
				?>
				
			    <div class="col-md-5">
				  <div class="card card-body border-0 shadow-sm bg-light">
					<h6 class="text-capitalize font-weight-600 mb-4">change your password</h6>
					<form action="" method="post">
					  <?php
						if(isset($password_success)){
							echo $password_success;
						}
					  ?>
					  <!-- === current password === -->
					  <div class="mb-3">
						<div class="input-group">
						  <span class="input-group-text"><i class="fa-solid fa-shield"></i></span>
						  <input type="password" name="current_pass" class="form-control box-shadow-none" placeholder="Current Password">
						</div>
						<?php 
							if(isset($currnet_pass)){
								echo "<span class='text-danger small'>".$currnet_pass."</span>";
							}
						?>
					  </div>
					  <!-- === new password === -->
					  <div class="mb-3">
						<div class="input-group">
						  <span class="input-group-text"><i class="fa-solid fa-key"></i></span>
						  <input type="password" name="new_pass" class="form-control box-shadow-none" placeholder="New Password">
						</div>
						<?php 
							if(isset($new_pass_str)){
								echo "<span class='text-danger small'>".$new_pass_str."</span>";
							}
						?>
					  </div>
					  <!-- === confirm password === -->
					  <div class="mb-3">
						<div class="input-group">
						  <span class="input-group-text"><i class="fa-solid fa-key"></i></span>
						  <input type="password" name="confirm_pass" class="form-control box-shadow-none" placeholder="New Password">
						</div>
					  </div>
					  <input type="submit" name="libchange_btn" class="btn btn-primary box-shadow-none" value="Change Password">	
					</form>
				  </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>