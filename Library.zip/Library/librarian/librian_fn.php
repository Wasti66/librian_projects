
<?php

	class lMstu{
		
		private $conn;
		
		public function __construct(){
			$host_name = "localhost";
			$host_user = "root";
			$db_pass = "";
			$db_name = "lms";
			
			$this->conn = mysqli_connect($host_name,$host_user,$db_pass,$db_name);
			if(!$this->conn){
				echo "Data base connection error";
			}
		}
		
		
		/* -- === librian panal === -- */
		
		/* -- === librian login check form === -- */
		public function librian_login($librian_login){
			
			$login_email_librian = $librian_login['login_email_librian'];
			$login_pass_librian = md5($librian_login['login_pass_librian']);
			
			$libria_login_sql = "SELECT * FROM librian WHERE email='$login_email_librian' OR username='$login_email_librian'";
			$libraian_query = mysqli_query($this->conn,$libria_login_sql);
			
			if(mysqli_num_rows($libraian_query) == 1){
				
				$liblian_info_assoc = mysqli_fetch_assoc($libraian_query);
				if($login_pass_librian == $liblian_info_assoc['password']){
					
					session_start();
					$_SESSION['id'] = $liblian_info_assoc['id'];
					$_SESSION['username'] = $liblian_info_assoc['username'];
					$_SESSION['email'] = $liblian_info_assoc['email'];
					$_SESSION['name'] = $liblian_info_assoc['name'];
					$_SESSION['username'] = $liblian_info_assoc['username'];
					header('location:index.php');
					
				}else{
					$lib_error_msg = "Your Password is incorrect!";
					return $lib_error_msg;
				}
				
			}else{
				$lib_error_msg = "Your Email or Username is incorrect!";
				return $lib_error_msg;
			}
			
		}
		
		/* -- === librian inactive === -- */
		public function librian_inactive($li_inid){
			$librian_inactive_sql = "UPDATE librian SET status='0' WHERE id=$li_inid";
			mysqli_query($this->conn,$librian_inactive_sql);
		}
		/* -- === librian active === -- */
		public function librian_active($li_acid){
			$librian_active_sql = "UPDATE librian SET status='1' WHERE id=$li_acid";
			mysqli_query($this->conn,$librian_active_sql);
		}
		/* -- === librian profile display id === -- */
		public function libprofileid($libprofileid){
			$libprofileid_sql = "SELECT * FROM librian WHERE id=$libprofileid";
			$libprofileid_query = mysqli_query($this->conn,$libprofileid_sql);
			return $libprofileid_query;
		}
		/* -- === librian profile update === -- */
		public function libup_profile($library_data){
			$up_id = $library_data['up_id'];
			$upuser_name = $library_data['upuser_name'];
			$up_name = $library_data['up_name'];
			$up_email = $library_data['up_email'];
			$up_phone = $library_data['up_phone'];
			
			$libprofile_update = "UPDATE librian SET username='$upuser_name',name='$up_name',email='$up_email',phone=$up_phone WHERE id=$up_id";
			if(mysqli_query($this->conn,$libprofile_update)){
				$success_msg = "Update Successfully!";
				return $success_msg;
			}
		}
		
		/* -- === librian profile delete === -- */
		public function profile_delete($libpro_delete){
			$libpro_deletesql = "DELETE FROM librian WHERE id=$libpro_delete";
			mysqli_query($this->conn,$libpro_deletesql);
		}
		
		
		/* -- === sludents information include librian dashboard === -- */
		public function studen_info_librian(){
			$student_info_sql = "SELECT * FROM students";
			if(mysqli_query($this->conn,$student_info_sql)){
				$student_info_return = mysqli_query($this->conn,$student_info_sql);
				return $student_info_return;
			}
		}
		
		/* -- === sludents active information === -- */
		public function studen_info_active(){
			$student_infoactive_sql = "SELECT * FROM students WHERE status='1'";
			if(mysqli_query($this->conn,$student_infoactive_sql)){
				$student_infoactive_return = mysqli_query($this->conn,$student_infoactive_sql);
				return $student_infoactive_return;
			}
		}
		/* -- === sludents active information id === -- */
		public function student_info_id($info_id){
			$student_id = $info_id['student_id'];
			$query_active = "SELECT * FROM students WHERE id=$student_id AND status='1'";
			if(mysqli_query($this->conn,$query_active)){
				return mysqli_query($this->conn,$query_active);
			}
		}
		
		/* -- === sludents information inactive librian dashboard === -- */
		public function student_inactive($student_inactive){
			$student_in_sql = "UPDATE students SET status='0' WHERE id=$student_inactive";
			$student_in_query = mysqli_query($this->conn,$student_in_sql);
			
		}
		/* -- === sludents information active librian dashboard === -- */
		public function student_active($student_active){
			$student_ac_sql = "UPDATE students SET status='1' WHERE id=$student_active";
			$student_ac_query = mysqli_query($this->conn,$student_ac_sql);
			
		}
		
		/* -- === add books librian dashboard === -- */
		public function add_book($book_data){
			
			$book_name =  ucfirst($book_data['book_name']);
			$book_autor_name = ucfirst($book_data['book_autor_name']);
			$book_publication_name = ucfirst($book_data['book_publication_name']);
			$purchase_date = $book_data['purchase_date'];
			$book_price = $book_data['book_price'];
			$book_qty = $book_data['book_qty'];
			$available_qty = $book_data['available_qty'];
			
			
			$img_name = $_FILES['img_name']['name'];
			$img_tmp_name = $_FILES['img_name']['tmp_name'];
			$img_size = $_FILES['img_name']['size'];
			$img_ext = pathinfo($img_name,PATHINFO_EXTENSION);
			$img_allowed = array('jpg','png','jepg','JPG','PNG','JEPG','svg','SVG');
			
			$error = [];
			
			if(strlen($book_name) < 3 || strlen($book_name) >86){
				$error['book_name'] = "Boook name must be 3-86 character!";
			}
			if(!in_array($img_ext,$img_allowed)){
				$error['img_ext'] = "Invalid file type. Only JPG, SVG and PNG types are accepted.";
			}
			if($img_size > 5242880){
				$error['img_size'] = "Image size exceeds 5MB";
			}
			if(strlen($book_autor_name) < 3 || strlen($book_autor_name) > 86){
				$error['author_name'] = "Author name must be 3-86 character!";
			}
			if(strlen($book_publication_name) < 3 || strlen($book_publication_name) > 86){
				$error['book_publication_name'] = "Book publication name must be 3-86 character!";
			}
			if(empty($purchase_date)){
				$error['date'] = "Date field is required!";
			}
			if(!is_numeric($book_price)){
				$error['book_int'] = "Please book price field required!";
			}
			if(!is_numeric($book_qty)){
				$error['book_qty'] = "Book quentity field is required!";
			}
			if(strlen($book_qty) > 5){
				$error['book_qty_digit'] = "Book quantity is 5 digit!";
			}
			if(!is_numeric($available_qty)){
				$error['available_qty'] = "Available quentity field is required!";
			}
			
			if(count($error) > 0){
				$action = [
					'status' => 'error',
					'message' => $error,
				];
				return $action;
			}else{
				
				$add_book_insert = "INSERT INTO books(book_name,book_images,book_autor_name,book_publicaton_name,book_purchase_date,book_price,book_qty,avable_qty,librian_user_name) VALUES('$book_name','$img_name','$book_autor_name','$book_publication_name','$purchase_date',$book_price,$book_qty,$available_qty,'wasti67')";
				if(mysqli_query($this->conn,$add_book_insert)){
					move_uploaded_file($img_tmp_name,'upload/'.$img_name);
					
					$action = [
						'status' => 'success',
						'message' => 'Add Books Save Successfully!',
					];
					return $action;
				}
			}
			
		}
		
		/* -- === add books display === -- */
		public function display_books(){
			$display_books = "SELECT * FROM books";
			$display_book_query = mysqli_query($this->conn,$display_books);
			return $display_book_query;
		}
		
		/* -- === add books display update value === -- */
		public function display_books_id($display_books_id){
			$display_books_id_sql = "SELECT * FROM books WHERE id=$display_books_id";
			$display_books_id_query = mysqli_query($this->conn,$display_books_id_sql);
			return $display_books_id_query;
		}
		
		/* -- === add books update === -- */
		public function update_books($up_books){
			
			$up_id = $up_books['up_id'];
			$up_book_name = ucwords($up_books['up_book_name']);
			$up_book_autor = ucwords($up_books['up_book_autor']);
			$up_publication_name = ucwords($up_books['up_publication_name']);
			$up_purchase_date = $up_books['up_purchase_date'];
			$up_book_price = $up_books['up_book_price'];
			$up_book_qty = $up_books['up_book_qty'];
			$up_available_qty = $up_books['up_available_qty'];
			
			$books_up_sql = "UPDATE books SET book_name='$up_book_name',book_autor_name='$up_book_autor',book_publicaton_name='$up_publication_name',book_purchase_date='$up_purchase_date',book_price=$up_book_price,book_qty=$up_book_qty,avable_qty=$up_available_qty WHERE id=$up_id";
			if(mysqli_query($this->conn,$books_up_sql)){
				$return_up_data = "Book Update Successfully";
				return $return_up_data;
			}
			
		}
		
		/* -- === add books images update === -- */
		public function books_img_update($book_img_id){
			
			$img_id = $book_img_id['img_id'];
			
			$up_img = $_FILES['up_img']['name'];
			$up_tmp_nmae = $_FILES['up_img']['tmp_name'];
			$up_img_size = $_FILES['up_img']['size'];
			$img_ext = pathinfo($up_img,PATHINFO_EXTENSION);
			$ext_allow = array('jpg','png','jepg','JPG','PNG','JEPG','SVG','svg');
			
			if(!in_array($img_ext,$ext_allow)){
				$book_msg = '<script type="text/javascript">
							   alert("Invalid file type. Only JPG, SVG and PNG types are accepted.");
							</script>';
				return $book_msg;
			}elseif($up_img_size > 5242880){
				$book_msg = '<script type="text/javascript">
							   alert("Image size exceeds 5MB");
							</script>';
				return $book_msg;
			}else{
				$up_img_query = "UPDATE books SET book_images='$up_img' WHERE id=$img_id";
				if(mysqli_query($this->conn,$up_img_query)){
					move_uploaded_file($up_tmp_nmae,'upload/'.$up_img);
					$book_msg = '<script type="text/javascript">
									alert("Images Update successfully");
							   </script>';
					return $book_msg;
				}
			}
		}
		
		/* -- === add books display managment delete === -- */
		public function books_delete($books_id){
			
			$delete_img_sql = "SELECT * FROM  books WHERE id=$books_id";
			$books_query = mysqli_query($this->conn,$delete_img_sql);
			$books_assoc = mysqli_fetch_assoc($books_query);
			$delete_img = $books_assoc['book_images'];
			
			$books_sql = "DELETE FROM `books` WHERE id=$books_id";
			if(mysqli_query($this->conn,$books_sql)){
				unlink("upload/".$delete_img);
			}
		}
		
		/* -- === add books display === -- */
		public function issue_books(){
			$issue_books_sql = "SELECT * FROM books WHERE `book_qty` > 0";
			$return_issue_book = mysqli_query($this->conn,$issue_books_sql);
			return $return_issue_book;
			
		}
		
		/* -- === add issue books insert form === -- */
		public function issue_books_insert($issue_insert){
			$student_id = $issue_insert['student_id'];
			$book_id = $issue_insert['book_id'];
			$book_issue_date = $issue_insert['book_issue_date'];
			
			$issue_insert = "INSERT INTO issue_book (student_id,book_id,book_issue_date) VALUES($student_id,$book_id,'$book_issue_date')";
			$issue_book_decress = "UPDATE books SET `avable_qty`=`avable_qty`-1 WHERE id=$book_id";
			mysqli_query($this->conn,$issue_book_decress);
			
			$issue_query = mysqli_query($this->conn,$issue_insert);
			return $issue_insert;
			
		}
		
		/* -- === issue books display return === -- */
		public function return_books(){
			$return_books_sql = "SELECT issue_book.id,issue_book.book_issue_date, students.name,students.roll,students.phone,books.book_name,books.book_images FROM issue_book INNER JOIN students ON students.id = issue_book.student_id INNER JOIN books ON books.id = issue_book.book_id WHERE issue_book.book_return_date=''";
			$return_books_query = mysqli_query($this->conn,$return_books_sql);
			return $return_books_query;
		}
		
		/* -- === issue books return === -- */
		public function issue_booksreturn($issuebookreturn){
			$issue_books_info = "SELECT * FROM issue_book";
			$issue_books_info_query = mysqli_query($this->conn,$issue_books_info);
			$issue_books_info_assoc = mysqli_fetch_assoc($issue_books_info_query);
			$issue_books_id = $issue_books_info_assoc['book_id'];
			
			$date = date('d-M-y');
			$books_return = "UPDATE issue_book SET book_return_date='$date' WHERE id=$issuebookreturn";
			$book_return_query = mysqli_query($this->conn,$books_return);
			
			if($book_return_query){
				$issue_books_incress = "UPDATE books SET avable_qty = avable_qty + 1 WHERE id=$issue_books_id";
				mysqli_query($this->conn,$issue_books_incress);
				return $book_return_query;
			}
			
			
		}
		
		/* -- === count total students === -- */
		public function total_student(){
			$total_students_sql = "SELECT * FROM students";
			$total_students_query = mysqli_query($this->conn,$total_students_sql);
			return $total_students_query;
		}
		
		/* -- === count total books === -- */
		public function total_books(){
			$tolat_books_sql = "SELECT * FROM books";
			$total_books_query = mysqli_query($this->conn,$tolat_books_sql);
			return $total_books_query;
		}
		
		/* -- === count total lirrian === -- */
		public function total_librian(){
			$total_librian_sql = "SELECT * FROM librian";
			$total_librian_query = mysqli_query($this->conn,$total_librian_sql);
			return $total_librian_query;
		}
		
	}

?>