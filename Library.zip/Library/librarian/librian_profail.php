<?php 
	
	require_once('librian_fn.php');
	$obj = new lMstu();
	$data = $obj->total_librian();
	
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <section class="bg-light shadow-sm pb-3">
			<div class="container">
			  <div class="row">
			    <div class="col">
				  <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
					  <ol class="breadcrumb mb-0">
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="index.php" class="text-decoration-none">Dashboard</a></li>
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="javascript:avoid(0)" class="text-decoration-none">Profile</a></li>
					  </ol>
				  </nav>
				</div>
			  </div> 
			</div>
		</section>
	    <!-- ===== home part ====== -->
	    <section class="">
			<div class="container">
			  <div class="row justify-content-center">
			    <?php while($row = mysqli_fetch_assoc($data)){?>
				
					<div class="col-lg-4 col-sm-6 col-11 text-center mb-3">
					  <div class="card card-body bg-light shadow-sm">
					    <h6 class="text-capitalize mt-2"><span class="me-2">user name :</span><?php echo $row['username']; ?></h6>
						<h6 class="text-capitalize"><span class="me-2">name :</span><?php echo $row['name']; ?></h6>
						<h6 class="text-capitalize"><span class="me-2">email :</span><?php echo $row['email']; ?></h6>
						<h6 class="text-capitalize"><span class="me-2">phone :</span>0<?php echo $row['phone']; ?></h6>
						<h6 class="text-capitalize"><span class="me-2">status :</span><?= $row['status'] == 1 ? 'Active' : 'Inactive' ?>
							
							<?php
								if($row['status'] == 1){
									?>
									<a href="ac_in.php?inactivelib=<?php echo base64_encode($row['id']); ?>" class="btn btn-success btn-sm box-shadow-none" onclick="return confirm('Are you confirm to Inactive ?')">
									   <i class="fa-solid fa-arrow-up"></i>
									</a>
									<?php
								}else{
									?>
									<a href="ac_in.php?activelib=<?php echo base64_encode($row['id']); ?>" class="btn btn-warning btn-sm box-shadow-none" onclick="return confirm('Are you confirm to Active ?')">
									  <i class="fa-solid fa-arrow-down"></i>
									</a>
									<?php
								}
							?>
							
						</h6>
						
						<div class="mt-2">
						  <a href="librianupdate_profile.php?librofileupdate=<?php echo base64_encode($row['id']); ?>" class="btn btn-primary btn-sm box-shadow-none">update profile</a>
						  
						  <a href="delete.php?libprofiledelete=<?php echo base64_encode($row['id']); ?>" class="btn btn-danger btn-sm box-shadow-none" onclick="return confirm('Are you sure delete this <?php echo $row['name']. ' Profile'.' ?'; ?>')">
							<i class="fa-regular fa-trash-can"></i>
						  </a>
						</div>

					  </div>
					</div>
				
				<?php } ?>
			  </div>
			</div>
		</section>
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>