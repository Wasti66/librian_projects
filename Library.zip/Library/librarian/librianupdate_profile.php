<?php 
	
	require_once('librian_fn.php');
	$obj = new lMstu();
	if(isset($_GET['librofileupdate'])){
		$id = base64_decode($_GET['librofileupdate']);
		$value = $obj->libprofileid($id);
		$row = mysqli_fetch_assoc($value);
	}
	
	if(isset($_POST['librianupdate_btn'])){
		$msg = $obj->libup_profile($_POST);
	}
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <section class="bg-light shadow-sm pb-3">
			<div class="container">
			  <div class="row">
			    <div class="col">
				  <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
					  <ol class="breadcrumb mb-0">
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="index.php" class="text-decoration-none">Dashboard</a></li>
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="javascript:avoid(0)" class="text-decoration-none">Update Profile</a></li>
					  </ol>
				  </nav>
				</div>
			  </div> 
			</div>
		</section>
	    <!-- ===== home part ====== -->
	    <section class="">
			<div class="container">
			  <div class="row justify-content-center">
			    <div class="col-lg-6 col-md-7">
				  <?php
					if(isset($msg)){
						echo '<div class="alert alert-primary">'.$msg.'</div>';
					}
				  ?>
				  <div class="card card-body shadow bg-light">
					<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
					  <input type="hidden" name="up_id" value="<?php echo $row['id']; ?>">
					  <!-- === update librian user name ==== -->
					  <div class="mb-3">
						<label class="form-label">User Name</label>
						<input type="text" name="upuser_name" class="form-control box-shadow-none" value="<?php echo $row['username']; ?>" required=''>
					  </div>
					  <!-- === update librian name ==== -->
					  <div class="mb-3">
						<label class="form-label">Name</label>
						<input type="text" name="up_name" class="form-control box-shadow-none text-capitalize" value="<?php echo $row['name']; ?>" required=''>
					  </div>
					  <!-- === update librian email ==== -->
					  <div class="mb-3">
						<label class="form-label">Email</label>
						<input type="text" name="up_email" class="form-control box-shadow-none" value="<?php echo $row['email']; ?>" required=''>
					  </div>
					  <!-- === update librian phone ==== -->
					  <div class="mb-3">
						<label class="form-label">Phone</label>
						<input type="number" name="up_phone" class="form-control box-shadow-none" value="<?php echo $row['phone']; ?>" required=''>
					  </div>
					  <input type="submit" name="librianupdate_btn" class="btn btn-primary box-shadow-none" value="Update Profile">
					</form>
				 </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>