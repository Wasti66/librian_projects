<?php 
	session_start();
	require_once('librian_fn.php');
	$obj = new lMstu(); 
	
	if(isset($_POST['librian_login_btn'])){
		$msg = $obj->librian_login($_POST);
	}
	if(isset($_SESSION['username'])){
		header('location:index.php');
	}
	
?>
<?php require_once('include/head.php'); ?> 
  <body> 
	 <main>
	    <!-- ===== home part ====== -->
	    <section class="bg-light vh-100 align-items-center d-flex">
			<div class="container">
			  <div class="row justify-content-center">
			    <div class="col-md-5">
				  <div class="card shadow-sm border-0">
				    <?php
						if(isset($msg)){
							echo "<span class='alert alert-danger'>".$msg."</span>";
						}
					?>
				    <img src="../images/Untitled design.jpg" class="card-img-top mb-3">
					<div class="card-body">
					  <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
							<!-- ==== EMAIL OR NAME ==== -->
							<div class="input-group mb-3 bg-transperant">
							  <div class="input-group-text bg-transparent text-muted"><i class="fa-solid fa-envelope"></i></div>
							  <input type="text" name="login_email_librian" class="form-control box-shadow-none" placeholder="Email or Username">
							</div>
							<!-- ==== password ==== -->
							<div class="input-group mb-3">
							  <div class="input-group-text bg-transparent text-muted"><i class="fa-solid fa-lock"></i></div>
							  <input type="password" name="login_pass_librian" class="form-control box-shadow-none" placeholder="Password">
							</div>
							<!-- ==== login btn ==== -->
							<input type="submit" name="librian_login_btn" value="Login" class="btn text-white form-control box-shadow-none mb-3" style="background-color:#000e20;">
							
							<!-- ==== rememberme and forgotpassword ==== -->
							<div class="d-flex">
							  <div class="form-check">
								<input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
								<label class="form-check-label" for="flexCheckDefault">
									Remember me
								</label>
							  </div>
							  <a href="#" class="text-decoration-none small ms-auto" style="margin-top:1px;">Forget Password</a>
							</div>
						
					  </form>
					</div>
				  </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
     <footer>
     </footer>  
	 <?php require_once('include/script.php'); ?>
    