<?php 
	
	require_once('librian_fn.php');
	$obj = new lMstu();
	$value = $obj->return_books();
	
	if(isset($_GET['id'])){
		$id = $_GET['id'];
		$return_books = $obj->issue_booksreturn($id);
		
		if($return_books){
			echo "<script type='text/javascript'>
					alert('Return Book Successfully');
					javascript:history.go(-1);
				  </script>";
		}			 
	}
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <section class="bg-light shadow-sm pb-3">
			<div class="container">
			  <div class="row">
			    <div class="col">
				  <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
					  <ol class="breadcrumb mb-0">
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="index.php" class="text-decoration-none">Dashboard</a></li>
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="javascript:avoid(0)" class="text-decoration-none">Return Books</a></li>
					  </ol>
				  </nav>
				</div>
			  </div> 
			</div>
		</section>
	    <!-- ===== home part ====== -->
	    <section>
			<div class="container">
			  <div class="row">
			    <div class="col-12">
				  <h3 class="text-capitalize">Return Books</h3>
				  <div class="card shadow-sm p-1 border-0 bg-light">
				    <!-- ==== search student information search ==== -->
					<div class="row justify-content-end mb-3 mt-3">
					  <div class="col-lg-3 col-md-5">
					    <form action="/Development/Library/librarian/students.php" method="post">
						   <div class="d-flex">
						     <input type="text" name="search" class="form-control box-shadow-none mx-1" placeholder="Search">
						     <button type="submit" name="btn_search" class="box-shadow-none btn p-0 text-muted">
								<i class="fa-solid fa-magnifying-glass position-absolute" style="right: 22px;top: 32px;"></i>
							 </button>
						   </div>
						</form>
					  </div>
					</div>
					
					<!-- ==== search student information table ==== -->
					<div class="table-responsive">
					  <table class="table table-hover table-striped table-bordered">
					    <thead>
						  <tr>
							<th>Name</th>
							<th>Roll</th>
							<th>Phone</th>
							<th>Book Name</th>
							<th>Images</th>
							<th>Issue Book Date</th>
							<th>Return Book</th>
						  </tr>
						</thead>
						<tbody>
						<?php while($row = mysqli_fetch_assoc($value)){?>
						  <tr>
							<td><?php echo $row['name'];?></td>
							<td><?php echo $row['roll'];?></td>
							<td>0<?php echo $row['phone'];?></td>
							<td><?php echo $row['book_name'];?></td>
							<td><img src="upload/<?php echo $row['book_images'];?>" class="w-4"></td>
							<td><?php echo $row['book_issue_date'];?></td>
							<td><a href="?id=<?php echo $row['id'];?>">Return Book</a></td>
						  </tr>
						<?php } ?>  
						</tbody>
					  </table>
					</div>
				  </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>