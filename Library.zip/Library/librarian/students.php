<?php 
	
	require_once('db.php');
	require_once('librian_fn.php');
	$obj = new lMstu();
	$data = $obj->studen_info_librian();
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <!-- ===== students part ====== -->
	    <section class="bg-light shadow-sm pb-3">
			<div class="container">
			  <div class="row">
			    <div class="col">
				  <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
					  <ol class="breadcrumb mb-0">
						<li class="breadcrumb-item font-weight-600 text-dark"><a href="index.php" class="text-decoration-none">Dashboard</a></li>
						<li class="breadcrumb-item font-weight-600 text-dark active" aria-current="page">Students</li>
					  </ol>
				  </nav>
				</div>
			  </div> 
			</div>
		</section>
		<!-- ===== students table information ====== -->
	    <section class="">
			<div class="container">
			  <div class="row">
			    <div class="col-12">
				  <h3 class="text-capitalize">students information</h3>
				  <div class="card shadow-sm p-1 border-0 bg-light">
				    <!-- ==== search student information search ==== -->
					<div class="row justify-content-end mb-3 mt-3">
					  <div class="col-lg-3 col-md-5">
					    <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
						   <div class="d-flex">
						     <input type="text" name="student_name" class="form-control box-shadow-none mx-1" placeholder="Search" required=''>
						     <button type="submit" name="btn_search" class="box-shadow-none btn p-0 text-muted">
								<i class="fa-solid fa-magnifying-glass position-absolute" style="right: 22px;top: 32px;"></i>
							 </button>
						   </div>
						</form>
					  </div>
					</div>
					
					<?php
					
						if(isset($_POST['btn_search'])){ 
						   $student_name = $_POST['student_name'];
						   
						   ?>
								
								<div class="table-responsive">
								  <table class="table table-hover">
									<thead>
									  <tr>
										<th>SL.NO</th>
										<th>Name</th>
										<th>Roll</th>
										<th>Reg</th>
										<th>Email</th>
										<th>Phone</th>
										<th>Status</th>
										<th>Action</th>
									  </tr>
									</thead>
									<tbody>
									  <?php
									  
										$student_search = mysqli_query($conn,"SELECT * FROM students WHERE `name` LIKE '%$student_name%'");
										$students_rows = mysqli_num_rows($student_search);
										if($students_rows > 0){
											
											while($student_assoc = mysqli_fetch_assoc($student_search)){ ?>
											
											   <tr>
												<td><?php echo $student_assoc['id'];?></td>
												<td><?php echo ucwords($student_assoc['name']); ?></td>
												<td><?php echo $student_assoc['roll'];?></td>
												<td><?php echo $student_assoc['reg'];?></td>
												<td><?php echo $student_assoc['email'];?></td>
												<td>0<?php echo $student_assoc['phone'];?></td>
												<td><?= $student_assoc['status'] == 1 ? 'Active' : 'Inactive' ?></td>
												<td>
													<?php
														if($student_assoc['status'] == 1){
														?>
														
															<a href="ac_in.php?id=<?php echo base64_encode($student_assoc['id']);?>" class="btn btn-success btn-sm box-shadow-none"><i class="fa-solid fa-arrow-up"></i></a>
															
															<?php
														}else{
															?>
															
															<a href="ac_in.php?id_ac=<?php echo base64_encode($student_assoc['id']);?>" class="btn btn-danger btn-sm box-shadow-none"><i class="fa-solid fa-arrow-down"></i></a>
															
															<?php
														}
													?>
												</td>
											  </tr>
														
												<?php
													
											}
											
										}else{
											echo "<h4 class='text-danger'>Not found!</h4>";
										}
									  
									  ?>
									</tbody>
								  </table>
								</div>	
								
						   <?php
						   
						}else{ ?>
								
							<!-- ==== search student information table ==== -->
							<div class="table-responsive">
							  <table class="table table-hover">
								<thead>
								  <tr>
									<th>SL.NO</th>
									<th>Name</th>
									<th>Roll</th>
									<th>Reg</th>
									<th>Email</th>
									<th>Phone</th>
									<th>Status</th>
									<th>Action</th>
								  </tr>
								</thead>
								<tbody>
								<?php while($row = mysqli_fetch_assoc($data)){ ?>
								  <tr>
									<td><?php echo $row['id'];?></td>
									<td><?php echo ucwords($row['name']); ?></td>
									<td><?php echo $row['roll'];?></td>
									<td><?php echo $row['reg'];?></td>
									<td><?php echo $row['email'];?></td>
									<td>0<?php echo $row['phone'];?></td>
									<td><?= $row['status'] == 1 ? 'Active' : 'Inactive' ?></td>
									<td>
										<?php
											if($row['status'] == 1){
											?>
											
												<a href="ac_in.php?id=<?php echo base64_encode($row['id']);?>" class="btn btn-success btn-sm box-shadow-none"><i class="fa-solid fa-arrow-up"></i></a>
												
												<?php
											}else{
												?>
												
												<a href="ac_in.php?id_ac=<?php echo base64_encode($row['id']);?>" class="btn btn-danger btn-sm box-shadow-none"><i class="fa-solid fa-arrow-down"></i></a>
												
												<?php
											}
										?>
									</td>
								  </tr>
								<?php } ?>  
								</tbody>
							  </table>
							</div>	
								
							<?php } ?>
				  </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>