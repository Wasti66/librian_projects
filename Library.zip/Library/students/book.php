<?php 
	
	require_once('../admin/function.php');
	require_once('../librarian/librian_fn.php');
	require_once('../students/db.php');
	$obj = new lMs();
	$obj2 = new lMstu();
	$books = $obj2->display_books();
	
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width bg-light"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <!-- ===== book part ====== -->
		<section class=""> 
		   <div class="container">
		     <div class="row mb-3">
			      <div class="col-12">
			   			<div class="card card-body border-0 shadow-sm">
  							<form action="" method="post">
  								 <div class="d-flex">
 									 <input type="text" name="book_name" class="form-control box-shadow-none me-2" placeholder="Search" required=''>
  								 	 <input type="submit" name="search" class="btn btn-primary box-shadow-none" value="search">
  								 </div>
  							</form>
			   			</div>
			      </div>
			   </div>

			   <?php

			   			if(isset($_POST['search'])){
			   					$data = $_POST['book_name']
			   				?>

			   					<div class="row">
							      <div class="col-12">
							   			<div class="card card-body border-0 shadow-sm">
				  							 <div class="row">
				  							 	<?php 
				  							 	$data = mysqli_query($conn,"SELECT * FROM books WHERE `book_name` LIKE '%$data%'");

				  							 	$num_rows = mysqli_num_rows($data);
				  							 	if($num_rows > 0){ ?>

				  							 			<?php
						  							 	while($row = mysqli_fetch_assoc($data)){ ?>
							  									<div class="col-lg-3 col-6 mb-2">
								  										<div class="card border-0 shadow-sm">
								  											<img src="../librarian/upload/<?= $row['book_images']; ?>" style="height: 120px;">
								  											<div class="card-body pt-1 ps-1">
								  												<h6><?php echo $row['book_name'];?></h6>
								  												<h6 class="small"><span class="text-capitalize me-2">book price :</span><?php echo $row['book_price'];?></h6>
								  												<h6 class="small"><span class="text-capitalize me-2">book quentity :</span><?php echo $row['book_qty'];?></h6>
								  												<h6 class="small"><span class="text-capitalize me-2">available quantity :</span><?php echo $row['avable_qty'];?></h6>
								  											</div>	
								  										</div>	
							  									</div>
						  								<?php } ?>

				  							 	<?php }else{
				  							 		echo "<h1 class='text-danger text-center p-4 text-capita'>this books are not available</h1>";
				  							 	} ?>

				  							 </div>
							   			</div>
							      </div>
							   </div>

			   				<?php

			   			}else{ ?>

						<div class="row">
						  <div class="col-12">
								<div class="card card-body border-0 shadow-sm">
									 <div class="row">
										<?php while($data = mysqli_fetch_assoc($books)){ ?>
												<div class="col-lg-3 col-6 mb-2">
														<div class="card border-0 shadow-sm bg-light">
															<img src="../librarian/upload/<?= $data['book_images']; ?>" style="height: 120px;">
															<div class="card-body pt-1 ps-1">
																<h6><?php echo $data['book_name'];?></h6>
																<h6 class="small"><span class="text-capitalize me-2">book price :</span><?php echo $data['book_price'];?></h6>
																<h6 class="small"><span class="text-capitalize me-2">book quentity :</span><?php echo $data['book_qty'];?></h6>
																<h6 class="small"><span class="text-capitalize me-2">available quantity :</span><?php echo $data['avable_qty'];?></h6>
															</div>	
														</div>	
												</div>
										<?php } ?>
									 </div>
								</div>
						  </div>
					   </div>

					<?php } ?>

			   
		   </div>
		</section>
	 </main>
	</body> 
  <footer>
  </footer>  
  <?php require_once('include/script.php'); ?>