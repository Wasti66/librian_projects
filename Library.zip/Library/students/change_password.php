<?php 
	
	require_once('../admin/function.php');
	require_once('db.php');
	require_once('include/head.php');
	$obj = new lMs();

	
?>

  <body class="offcanvas-width bg-light"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <!-- ===== home part ====== -->
	    <section class="vh-100 d-flex align-items-center">
			<div class="container">
			  <div class="row justify-content-center">
			    <div class="col-md-6">
				  <h3 class="fw-bold text-capitalize mb-3 text-muted">change password</h3>
				  <div class="card card-body border-0 shadow">
				    <?php
					
						$error_current = $new_confirn ="";
						if(isset($_POST['pass_btn'])){
							$id = $_SESSION['id'];
							$select = "SELECT * FROM students WHERE id=$id";
							$query = mysqli_query($conn,$select);
							$assoc = mysqli_fetch_assoc($query);
							$old_pass = $assoc['password'];
							
							$current_pass = md5($_POST['current_pass']);
							$new_pass = md5($_POST['new_pass']);
							$confirm_pass = md5($_POST['confirm_pass']);
							
							if($old_pass == $current_pass){
								
								if($new_pass == $confirm_pass){
									
									$update_pass = "UPDATE students SET password='$new_pass' WHERE id=$id";
									if(mysqli_query($conn,$update_pass)){
										echo "<script type='text/javascript'>
												alert('Password Update Successfully');
											 </script>";
									}else{
										echo "Password Update not Successfully";
									}
									
								}else{
									$new_confirn = "New Password and Confirm are not match";
								}
								
							}else{
								$error_current = "Current Password is worng";
							}

							
						}
					?>
					<form action="" method="post">
					  <!-- ==== current pass ==== -->
					  <div class="mb-3 mt-3">
						  <div class="input-group">
							<span class="input-group-text bg-transparent" id="basic-addon1"><i class="fa-solid fa-shield"></i></span>
							<input type="password" name="current_pass" class="form-control box-shadow-none" placeholder="Current Password" value="">
						  </div>
						  <?php
							if(isset($error_current)){ 
							  echo "<span class='text-danger'>".$error_current."</span>";
							}
						  ?>
					  </div>
					  <!-- ==== new pass ==== -->
					  <div class="mb-3">
						  <div class="input-group">
							<span class="input-group-text bg-transparent" id="basic-addon1"><i class="fa-solid fa-key"></i></span>
							<input type="password" name="new_pass" class="form-control box-shadow-none" placeholder="New Password">
						  </div>
						  <?php
							if(isset($new_confirn)){ 
							  echo "<span class='text-danger'>".$new_confirn."</span>";
							}
						  ?>
					  </div>
					  <!-- ==== current pass ==== -->
					  <div class="input-group mb-3">
						<span class="input-group-text bg-transparent" id="basic-addon1"><i class="fa-solid fa-key"></i></span>
						<input type="password" name="confirm_pass" class="form-control box-shadow-none" placeholder="New Password" required>
					  </div>
					  <input type="submit" name="pass_btn" class="btn btn-primary box-shadow-none mb-3" value="Change Password" required>
					</form>
				  </div>	
				</div>
			  </div> 
			</div>
		</section>
	 </main>
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>