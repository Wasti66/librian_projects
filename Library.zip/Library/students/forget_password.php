<?php 

	require_once('include/head.php');
	require_once('../admin/function.php');
	//require_once('db.php');
	$obj = new lMs(); 

	session_start();
	if(isset($_SESSION['email'])){
		header('location:index.php');
	}
	if(isset($_POST['recovery_btn'])){
		$recovery_msg = $obj->forget_password($_POST);
	}
	
	
?>

  <body> 
	 <main>
	    <!-- ===== home part ====== -->
	    <section class="bg-light vh-100 align-items-center d-flex">
			<div class="container">
			  <div class="row justify-content-center">
			    <div class="col-lg-4 col-md-5">
				  <div class="card shadow-sm border-0">
				    <img src="../images/Untitled design.jpg" class="card-img-top mb-3">
					<div class="card-body">
					  <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
					    <?php
							if(isset($recovery_msg)){
								echo "<span class='font-weight-600'>".$recovery_msg."</span>";
							}
						?>
					    <!-- ==== RECOVERY EMAIL ==== -->
					    <div class="input-group mb-3 bg-transperant">
						  <div class="input-group-text bg-transparent text-muted"><i class="fa-solid fa-envelope"></i></div>
						  <input type="text" name="to_email" class="form-control box-shadow-none" placeholder="Email">
						</div>
						<!-- ==== login btn ==== -->
						<input type="submit" name="recovery_btn" value="Recovery Password" class="btn text-white form-control box-shadow-none mb-3" style="background-color:#000e20;">
						
					  </form>
					</div>
					<!-- ==== login link ==== -->
					<div class="card-footer">
					  <div class="text-end">
					    <a href="login.php" class="text-decoration-none small">Login</a>
					  </div>
					</div>
				  </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
     <footer>
     </footer>  
	 <?php require_once('include/script.php'); ?>
    