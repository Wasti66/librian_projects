<?php
	
	require_once('../admin/function.php');
	$obj = new lMs();
	$page = explode('/',$_SERVER['PHP_SELF']);
	$page = end($page);
?>

<!doctype html>
<html lang="en">
  <head>
     <!-- Required meta tags -->
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <!--Company Icon-->
	 <link rel="icon" type="text/css"href="image/">
	 <link rel="icon" href="image/favicon.ico" type="image/">
	 <!--Fontawesome-->
	 <link rel="stylesheet" type="text/css" href="../assets/css/all.css"> 
     <!-- Bootstrap CSS -->
	 <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	 <!--global stylesheet css-->
	 <link rel="stylesheet" href="../assets/css/global.css">
	 <!--stylesheet css-->
	 <link rel="stylesheet" href="../assets/css/style.css">
  </head>
  