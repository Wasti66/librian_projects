
<?php
	session_start();
	if(!isset($_SESSION['email'])){
		header('location:login.php');
	}
?>

<header>
	
	<nav class="navbar navbar-expand-lg navbar-light bg-info fixed-top">
		  <div class="container-fluid">
		    <a class="navbar-brand" href="#">Navbar</a>
			
			<button class="navbar-toggler me-auto box-shadow-none d-md-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
			  <span class="navbar-toggler-icon" data-bs-target="#offcanvasExample"></span>
		    </button>
			
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			   <span class="navbar-toggler-icon"></span>
			</button>
			
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
			  <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
			    <li class="nav-item">
				  <a class="nav-link btn btn-dark box-shadow-none text-white" aria-current="page" href="logout.php">Logout</a>
				</li>
			   </ul>	
			</div>
		  </div>
		</nav>
		<div class="offcanvas offcanvas-start bg-dark border-0 shadow-sm" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
		  <div class="text-end pt-2">
			<button type="button" class="btn btn-sm box-shadow-none text-reset d-md-none" data-bs-dismiss="offcanvas" aria-label="Close">
			   <h5 class="text-light"><i class="fa-solid fa-xmark"></i></h5>
			</button>
		  </div>
		  <div class="offcanvas-body p-1">
		    <ul class="nav flex-column">
			  <li class="<?= $page == 'index.php' ? 'nav-item': '' ?>">
				<a class="nav-link text-white" aria-current="page" href="index.php"><i class="fa-solid fa-house"></i> Dashboard</a>
			  </li>
			  <li class="<?= $page == 'book.php' ? 'nav-item': '' ?>">
				<a class="nav-link text-white" aria-current="page" href="book.php"><i class="fa-solid fa-book me-2"></i></i>Book</a>
			  </li>
			  <li class="<?= $page == 'profail.php' ? 'nav-item': '' ?>">
				<a class="nav-link text-white" aria-current="page" href="profail.php"><i class="fa-solid fa-user me-2"></i></i>Profail</a>
			  </li>
			  <li class="<?= $page == 'change_password.php' ? 'nav-item': '' ?>">
				<a class="nav-link text-white" href="change_password.php"><i class="fa-solid fa-gear me-2"></i>Change Password</a>
			  </li>
			</ul>
		  </div>
		</div>
	 </header>

