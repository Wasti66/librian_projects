<?php 
	
	require_once('../admin/function.php');
	require_once('db.php');
	$obj = new lMs();
	
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width bg-light"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <!-- ===== home part ====== -->
		<section class="bb-5"> 
		   <div class="container">
		     <div class="row">
			   <div class="col-md-11 text-end">
			     <?php
					echo '<h4 class="fw-bold text-success">'.$_SESSION['name'].'</h4>';
				?>
			   </div>
			 </div>
		   </div>
		</section>
	    <section class="pt-0">
			<div class="container">
			  <div class="row justify-content-center">
			    <div class="col-md-11">
				   <div class="card card-body bg-light border-0 shadow-sm">
				     <div class="table-responsive">
						<table class="table table-bordered border-dark table-hover bg-white">
						  <thead>
							<tr>
							  <th scope="col">Book Name</th>
							  <th scope="col">Book Image</th>
							  <th scope="col">Issue Date</th>
							</tr>
						  </thead>
						  <tbody>
							<?php
								$id = $_SESSION['id'];
								
								$issue_query = mysqli_query($conn,"SELECT issue_book.book_issue_date, books.book_name,books.book_images FROM books INNER JOIN issue_book ON issue_book.book_id = books.id WHERE issue_book.student_id = $id");
								
								while($data = mysqli_fetch_assoc($issue_query)){?>
									<tr>
									  <td><?= $data['book_name']; ?></td>
									  <td><img src="../librarian/upload/<?= $data['book_images']; ?>" class="w-4"></td>
									  <td><?= $data['book_issue_date']; ?></td>
									</tr>
									<?php
								}
							
							?>
						  </tbody>
							  
						  </table>
					   </div>
				   </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>