<?php 

    require_once('include/head.php');
	require_once('../admin/function.php');
	$obj = new lMs(); 
	if(isset($_POST['login_btn'])){
		$error_msg = $obj->student_login($_POST);
	}
	session_start();
	if(isset($_SESSION['email'])){
		header('location:index.php');
	}
	
?>

  <body> 
	 <main>
	    <!-- ===== home part ====== -->
	    <section class="bg-light vh-100 align-items-center d-flex">
			<div class="container">
			  <div class="row justify-content-center">
			    <div class="col-lg-4 col-md-5">
				  <div class="card shadow-sm border-0">
				    <?php
						if(isset($error_msg)){
							echo "<span class='alert alert-danger mb-0 p-2'>".$error_msg."</span>";
						}
					?>
				    <img src="../images/Untitled design.jpg" class="card-img-top mb-3">
					<div class="card-body">
					  <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
					    <!-- ==== EMAIL OR NAME ==== -->
					    <div class="input-group mb-3 bg-transperant">
						  <div class="input-group-text bg-transparent text-muted"><i class="fa-solid fa-envelope"></i></div>
						  <input type="text" name="login_email" class="form-control box-shadow-none text-capitalize" placeholder="Email or Name">
						</div>
						<!-- ==== password ==== -->
						<div class="input-group mb-3">
						  <div class="input-group-text bg-transparent text-muted"><i class="fa-solid fa-lock"></i></div>
						  <input type="password" name="login_pass" class="form-control box-shadow-none" placeholder="Password">
						</div>
						
						
						
						<!-- ==== login btn ==== -->
						<input type="submit" name="login_btn" value="Login" class="btn text-white form-control box-shadow-none mb-3" style="background-color:#000e20;">
						
						<!-- ==== rememberme and forgotpassword ==== -->
						<div class="d-flex">
						  <div class="form-check">
							<input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
							<label class="form-check-label" for="flexCheckDefault">
								Remember me
							</label>
						  </div>
						  <a href="forget_password.php" class="text-decoration-none small ms-auto" style="margin-top:1px;">Forget Password</a>
						</div>
						
					  </form>
					</div>
					<!-- ==== registration link ==== -->
					<div class="card-footer">
					  <div class="text-end">
					    <a href="registration.php" class="text-decoration-none small">Create an account</a>
					  </div>
					</div>
				  </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
     <footer>
     </footer>  
	 <?php require_once('include/script.php'); ?>
    