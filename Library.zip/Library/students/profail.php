<?php 
	
	require_once('../admin/function.php');
	require_once('db.php');
	$obj = new lMs();
	
	
?>
  <?php require_once('include/head.php'); ?>
  <body class="offcanvas-width bg-light"> 
     <?php include('include/header.php'); ?>
	 <main>
	    <!-- ===== home part ====== -->
		<section class="vh-100 align-items-center d-flex"> 
		   <div class="container">
		     <div class="row justify-content-center">
			   <div class="col-md-5 col-sm-12 col-11">
			      <div class="card card-body shadow border-0 bg-light text-center" style="border-radius: 12px;">
			      	 <?php
			      	 		$id = $_SESSION['id'];
			      	 		$student_info = "SELECT * FROM students WHERE id=$id";
			      	 		$student_query = mysqli_query($conn,$student_info);
			      	 		$student_aaaoc = mysqli_fetch_assoc($student_query);
									//$img = $student_aaaoc['img'];
			      	 		?>
			      	 		<div class="m-auto">
										<div class="bg-light d-flex rounded-circle" style="height: 120px;width: 120px;">
											<i class="fa-regular fa-user fa-2x m-auto"></i>	
										</div>
										<img src="../librarian/upload/<?php echo $student_aaaoc['img'] ?>" class="rounded-circle m-auto position-absolute border-0" style="height: 120px; width: 120px;top: 1rem; left: 10rem;">
			      	 		</div>
			      	 		<h5 class="mt-3 font-weight-400"><?php echo $student_aaaoc['name']?></h5>
									<h5 class="font-weight-400"><?php echo $student_aaaoc['email']?></h5>
									<h5 class="font-weight-400">0<?php echo $student_aaaoc['phone']?></h5>
									<h5 class="font-weight-400"><span class="me-2">Reg :</span><?php echo $student_aaaoc['reg']?></h5>
									<h5 class="font-weight-400 mb-3"><span class="me-2">Roll :</span><?php echo $student_aaaoc['roll']?></h5>
							
									<!-- update profail -->
									<button type="button" class="btn btn-outline-primary box-shadow-none mb-3" data-bs-toggle="modal" data-bs-target="#profail-<?php echo $student_aaaoc['id']; ?>">
									  Update profile
									</button>

									<!-- Modal -->
									<div class="modal fade" id="profail-<?php echo $student_aaaoc['id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
									  <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
									    <div class="modal-content">
									      <div class="modal-header">
									        <h5 class="modal-title" id="exampleModalLabel">Update Profile</h5>
									        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
									      </div>
									      <div class="modal-body">

									      	 <?php

									      	 		if(isset($_POST['change_pro_btn'])){
									      	 			  $id	= $student_aaaoc['id'];
									      	 				$up_name = $_POST['up_name'];
									      	 				$up_email = $_POST['up_email'];
									      	 				$up_phone = $_POST['up_phone'];
									      	 				$up_reg = $_POST['up_reg'];
									      	 				$up_roll = $_POST['up_roll'];

									      	 				$up_img = $_FILES['up_img']['name'];
									      	 				$up_tmp_name = $_FILES['up_img']['tmp_name'];
									      	 				$up_img_size = $_FILES['up_img']['size'];
									      	 				$up_img_ext = pathinfo($up_img,PATHINFO_EXTENSION);
									      	 				$allow = array('jpg','png','jepg','JPG','PNG','JEPG','svg','SVG');

									      	 				if(!in_array($up_img_ext,$allow)){
									      	 						echo "<script type='text/javascript'>
									      	 											alert('Invalid file type. Only JPG, SVG and PNG types are accepted.');
									      	 									</script>";
									      	 				}elseif($up_img_size > 5242880){
								      	 							echo "<script type='text/javascript'>
								      	 											alert('Image size exceeds 5MB.');
								      	 									</script>";
									      	 				}else{

									      	 						$up_student = "UPDATE students set name='$up_name',email='$up_email',phone=$up_phone,reg=$up_reg,roll=$up_roll,img='$up_img' WHERE id=$id";
										      	 					if(mysqli_query($conn,$up_student)){
										      	 							move_uploaded_file($up_tmp_name,'../librarian/upload/'.$up_img);
										      	 							echo "<script type='text/javascript'>
	 																								alert('Profail update successfully');
	 																								javascript:history.go(-1);
										      	 									</script>";
										      	 					}

									      	 				}
									      	 					
									      	 					
									      	 		}
									      	 ?>	

									         <!-- update profail form -->
									      	 <form action="" method="post" enctype="multipart/form-data">
									      	 	  <input type="hidden" value="<?php echo $student_aaaoc['id']; ?>">
									      	 	  <div class="mb-3 text-start">
															  <label class="form-label">Change Photo</label>
															  <input type="file" name="up_img" class="form-control box-shadow-none" value="<?php echo $student_aaaoc['img']; ?>">
															</div>
									      	 		<!-- ==== update name ==== -->
									      	 		<div class="mb-3 text-start">
															  <label class="form-label">Change Name</label>
															  <input type="text" name="up_name" class="form-control box-shadow-none" value="<?php echo $student_aaaoc['name']; ?>" required>
															</div>
															<!-- ==== update email ==== -->
									      	 		<div class="mb-3 text-start">
															  <label class="form-label">Change Email</label>
															  <input type="email" name="up_email" class="form-control box-shadow-none" placeholder="Update Name" value="<?php echo $student_aaaoc['email']; ?>" required>
															</div>
															<!-- ==== update phone ==== -->
									      	 		<div class="mb-3 text-start">
															  <label class="form-label">Change Phone</label>
															  <input type="text" name="up_phone" class="form-control box-shadow-none" value="<?php echo $student_aaaoc['phone']; ?>" required>
															</div>
															<!-- ==== update reg ==== -->
									      	 		<div class="mb-3 text-start">
															  <label class="form-label">Change Reg</label>
															  <input type="text" name="up_reg" class="form-control box-shadow-none" value="<?php echo $student_aaaoc['reg']; ?>" required>
															</div>
															<!-- ==== update roll ==== -->
									      	 		<div class="mb-3 text-start">
															  <label class="form-label">Change Roll</label>
															  <input type="text" name="up_roll" class="form-control box-shadow-none" value="<?php echo $student_aaaoc['roll']; ?>" required>
															</div>
															<input type="submit" name="change_pro_btn" class="btn btn-primary box-shadow-none">
									      	 </form>

									      </div>
									    </div>
									  </div>
									</div>
							
			      	 		<?php
			      	 ?>

			      </div>
			   </div>
			 </div>
		   </div>
		</section>
	    
	 </main>
	</body> 
     <footer>
     </footer>  
    <?php require_once('include/script.php'); ?>