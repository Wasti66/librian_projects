
<?php
	session_start();
	require_once('../admin/function.php');
	$obj = new lMs();
	
	if(isset($_POST['reg_btn'])){
		$oldvalue = $_POST;
		$check = $obj->student_reg($_POST);
		if($check['status'] == 'error'){
			$error = $check['message'];
		}else{
			$success = $check['message'];
		}
	}
	if(isset($_SESSION['email'])){
		header('location:index.php');
	}

?>

<?php require_once('include/head.php'); ?>
  <body> 
	 <main>
	    <!-- ===== students registration part ====== -->
	    <section class="bg-light">
			<div class="container">
			  <div class="row justify-content-center">
			    <div class="col-md-6">
				  <?php
						if(isset($success)){
							?>
							
							<div class="alert alert-success" role="alert">
							  <?php echo $success; ?>
							</div>
							<?php

						}
					?> 
				  <div class="card">
				    <img src="../images/Untitled design.jpg" class="card-img-top mb-3">
					<div class="card-body">
					  <form action="" method="post">
					    <!-- === students name === -->
						<div class="mb-3">
							<div class="input-group">
							  <div class="input-group-text bg-transparent">
							   <i class="fa-regular fa-user"></i>
							  </div>
							  <input type="text" name="name" class="form-control box-shadow-none text-capitalize" placeholder="Name" value="<?php echo (isset($error) && count($error) > 0 ? $oldvalue['name'] : '');?>">
							</div>
							
							<?php
								if(isset($error) && isset($error['name'])){
									echo "<span class='text-danger small'>".$error['name']."</span>";
								}
							?>
							
							<?php
								if(isset($error) && isset($error['check_name'])){
									echo "<span class='text-danger small'>".$error['check_name']."</span>";
								}
							?>
						</div>
						<!-- === students email === -->
						<div class="mb-3">
						   <div class="input-group">
							  <div class="input-group-text bg-transparent">
								<i class="fa-regular fa-envelope"></i>
							  </div>
							  <input type="text" name="email" class="form-control box-shadow-none" placeholder="Email" value="<?php echo (isset($error) && count($error) > 0 ? $oldvalue['email'] : '');?>">
						   </div>
						   
						   <?php
								if(isset($error) && isset($error['check_email'])){
									echo "<span class='text-danger small'>".$error['check_email']."</span>";
								}
						   ?>
						   
						   <?php
							if(isset($error) && isset($error['email'])){
								echo "<span class='text-danger small'>".$error['email']."</span>";
							}
						   ?>
						   
						</div>
						<!-- === students roll === -->
						<div class="mb-3">
						  <div class="input-group">
							  <div class="input-group-text bg-transparent">
								<i class="fa-regular fa-id-badge"></i>
							  </div>
							  <input type="text" name="roll" class="form-control box-shadow-none" placeholder="Roll" value="<?php echo (isset($error) && count($error) > 0 ? $oldvalue['roll'] : '');?>">
						  </div>
						  
						  <?php
							if(isset($error) && isset($error['roll'])){
								echo "<span class='text-danger small'>".$error['roll']."</span>";
							}
						   ?>
						  
						</div>
						
						<!-- === students reg === -->
						<div class="mb-3">
						  <div class="input-group">
							  <div class="input-group-text bg-transparent">
								<i class="fa-regular fa-clipboard"></i>
							  </div>
							  <input type="text" name="reg" class="form-control box-shadow-none" placeholder="Reg No" value="<?php echo (isset($error) && count($error) > 0 ? $oldvalue['reg'] : '');?>">
						  </div>
						  
						  <?php
							if(isset($error) && isset($error['reg'])){
								echo "<span class='text-danger small'>".$error['reg']."</span>";
							}
						   ?>
						  
						</div>
						
						<!-- === students phone === -->
						<div class="mb-3">
						   <div class="input-group">
							  <div class="input-group-text bg-transparent">
								<i class="fa-solid fa-mobile-screen-button"></i>
							  </div>
							  <input type="text" name="phone" class="form-control box-shadow-none" placeholder="Phone" value="<?php echo (isset($error) && count($error) > 0 ? $oldvalue['phone'] : '');?>">
							</div>
							
							<?php
								if(isset($error) && isset($error['check_phone'])){
									echo "<span class='text-danger small'>".$error['check_phone']."</span>";
								}
							?>
							<?php
								if(isset($error) && isset($error['phone'])){
									echo "<span class='text-danger small'>".$error['phone']."</span>";
								}
						    ?>
							
						</div>
						
						<!-- === students new password === -->
						<div class="mb-3">
						  <div class="form-group">
						    <input type="password" name="password" class="form-control box-shadow-none" placeholder="Password">
						  </div>
						  <?php
							if(isset($error) && isset($error['password'])){
								echo "<span class='text-danger small'>".$error['password']."</span>";
							}
						  ?>
						</div>
						<input type="submit" name="reg_btn" value="Registration" class="btn text-white form-control box-shadow-none mb-3" style="background-color:#000e20;">
					  </form>
					</div>
					<div class="card-footer">
					  <div class="text-end">
					    <a href="login.php" class="text-decoration-none small">Login</a>
					  </div>
					</div>
				  </div>
				</div>
			  </div> 
			</div>
		</section>
	 </main>
     <footer>
     </footer>  
	 <?php require_once('include/script.php'); ?>
    